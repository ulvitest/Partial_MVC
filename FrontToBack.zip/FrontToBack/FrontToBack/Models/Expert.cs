﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBack.Models
{
    public class Expert
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Duty { get; set; }
        public string ImageUrl { get; set; }
    }
}
